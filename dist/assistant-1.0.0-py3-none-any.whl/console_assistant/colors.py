G = "\033[1;92m"  # GREEN
B = "\033[1;96m"  # Blue
P = "\033[4;95m"  # Pink
R = "\033[1;91m"  # Red
N = "\033[0m"  # Reset
Y = "\033[0;93m"  # Yellow
W = "\033[97m"  # White
